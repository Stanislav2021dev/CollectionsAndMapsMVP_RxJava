package com.example.colmapsrxjavatask4.di;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class BaseApp extends Application {
}
